import javax.swing.*;
import java.awt.*;
import java.util.Stack;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LL1ParserGUI extends JFrame {
    // LL(1)分析表
    private static final String[][] analysisTable = {
            // i  +  *  (  )  #
            {"TG", "", "", "TG", "", ""}, // E
            {"", "+TG", "", "", "ε", "ε"}, // G
            {"FQ", "", "", "FQ", "", ""}, // T
            {"", "ε", "*FQ", "", "ε", "ε"}, // Q
            {"i", "", "", "(E)", "", ""} // F
    };

    // 非终结符索引
    private static final int E = 0;
    private static final int G = 1;
    private static final int T = 2;
    private static final int Q = 3;
    private static final int F = 4;

    // 终结符索引
    private static final int i = 0;
    private static final int plus = 1;
    private static final int star = 2;
    private static final int leftParen = 3;
    private static final int rightParen = 4;
    private static final int endMarker = 5;

    private JTextField inputField;
    private JTextArea resultArea;
    private JButton analyzeButton;
    private JButton exportButton;

    public static void main(String[] args) {
        try {
            // 设置外观
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            // 创建日志文件
            createLogFile("程序启动");
            
            SwingUtilities.invokeLater(() -> {
                try {
                    new LL1ParserGUI().setVisible(true);
                } catch (Exception e) {
                    logError("GUI初始化失败", e);
                    showErrorDialog("程序启动失败：" + e.getMessage());
                }
            });
        } catch (Exception e) {
            logError("程序主线程异常", e);
            showErrorDialog("程序启动失败：" + e.getMessage());
        }
    }

    private static void createLogFile(String message) {
        try {
            File logFile = new File("LL1Parser.log");
            try (FileWriter fw = new FileWriter(logFile, true)) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                fw.write("\n" + sdf.format(new Date()) + " - " + message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void logError(String message, Exception e) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            createLogFile(message + "\n" + sw.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(null, message, "错误", JOptionPane.ERROR_MESSAGE);
    }

    public LL1ParserGUI() {
        try {
            // 设置窗口基本属性
            setTitle("LL(1)语法分析器 23智72黄暄");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(new BorderLayout(10, 10));
            
            // 创建输入面板
            JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
            inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
            
            JLabel inputLabel = new JLabel("请输入符号串（以#结束）：");
            inputField = new JTextField();
            inputPanel.add(inputLabel, BorderLayout.NORTH);
            inputPanel.add(inputField, BorderLayout.CENTER);

            // 创建按钮面板
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
            analyzeButton = new JButton("分析");
            exportButton = new JButton("导出结果");
            exportButton.setEnabled(false);
            buttonPanel.add(analyzeButton);
            buttonPanel.add(exportButton);
            inputPanel.add(buttonPanel, BorderLayout.SOUTH);

            // 创建结果显示区域
            resultArea = new JTextArea(15, 40);
            resultArea.setEditable(false);
            resultArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
            JScrollPane scrollPane = new JScrollPane(resultArea);
            scrollPane.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));

            // 添加组件到窗口
            add(inputPanel, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);

            // 添加分析按钮事件监听
            analyzeButton.addActionListener(e -> {
                try {
                    String input = inputField.getText().trim();
                    if (!input.endsWith("#")) {
                        showResult("输入格式错误，符号串必须以#结束");
                        exportButton.setEnabled(false);
                        return;
                    }
                    analyze(input);
                    exportButton.setEnabled(true);
                } catch (Exception ex) {
                    logError("分析过程出错", ex);
                    showResult("分析过程出错：" + ex.getMessage());
                    exportButton.setEnabled(false);
                }
            });

            // 添加导出按钮事件监听
            exportButton.addActionListener(e -> {
                try {
                    exportResult();
                } catch (Exception ex) {
                    logError("导出结果出错", ex);
                    showErrorDialog("导出失败：" + ex.getMessage());
                }
            });

            // 设置窗口大小和位置
            pack();
            setLocationRelativeTo(null);
            
            createLogFile("GUI初始化完成");
        } catch (Exception e) {
            logError("GUI构造函数异常", e);
            throw e;
        }
    }

    private void showResult(String message) {
        resultArea.setText(message);
    }

    private void analyze(String input) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();
        stack.push('#');
        stack.push('E');

        result.append("分析过程：\n");
        result.append("初始栈：[#, E]\n");

        int inputIndex = 0;
        char a = input.charAt(inputIndex);

        while (!stack.isEmpty()) {
            char X = stack.pop();
            result.append(String.format("当前栈顶：%c, 当前输入：%c\n", X, a));

            if (Character.isUpperCase(X)) {
                int nonTerminalIndex = getNonTerminalIndex(X);
                int terminalIndex = getTerminalIndex(a);
                String production = analysisTable[nonTerminalIndex][terminalIndex];
                
                if ("".equals(production)) {
                    showResult(result.toString() + "\n错误：分析表中无对应产生式");
                    return;
                } else if (!"ε".equals(production)) {
                    for (int i = production.length() - 1; i >= 0; i--) {
                        stack.push(production.charAt(i));
                    }
                    result.append(String.format("使用产生式：%c → %s\n", X, production));
                    result.append("当前栈：" + stack.toString() + "\n");
                }
            } else if (X == a) {
                if (X != '#') {
                    inputIndex++;
                    if (inputIndex < input.length()) {
                        a = input.charAt(inputIndex);
                    }
                }
            } else {
                showResult(result.toString() + "\n错误：栈顶符号与当前输入符号不匹配");
                return;
            }
        }

        if (inputIndex == input.length() - 1 && a == '#') {
            showResult(result.toString() + "\n分析结果：符号串是文法的句子");
        } else {
            showResult(result.toString() + "\n分析结果：符号串不是文法的句子");
        }
    }

    private static int getNonTerminalIndex(char nonTerminal) {
        switch (nonTerminal) {
            case 'E': return E;
            case 'G': return G;
            case 'T': return T;
            case 'Q': return Q;
            case 'F': return F;
            default: return -1;
        }
    }

    private static int getTerminalIndex(char terminal) {
        switch (terminal) {
            case 'i': return i;
            case '+': return plus;
            case '*': return star;
            case '(': return leftParen;
            case ')': return rightParen;
            case '#': return endMarker;
            default: return -1;
        }
    }

    private void exportResult() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("保存分析结果");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
            }
            public String getDescription() {
                return "文本文件 (*.txt)";
            }
        });

        // 设置默认的文件名
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String defaultFileName = "LL1分析结果_" + sdf.format(new Date()) + ".txt";
        fileChooser.setSelectedFile(new File(defaultFileName));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            // 如果文件名没有.txt后缀，添加它
            if (!file.getName().toLowerCase().endsWith(".txt")) {
                file = new File(file.getParentFile(), file.getName() + ".txt");
            }
            
            // 如果文件已存在，询问是否覆盖
            if (file.exists()) {
                int result = JOptionPane.showConfirmDialog(this,
                    "文件已存在，是否覆盖？",
                    "确认覆盖",
                    JOptionPane.YES_NO_OPTION);
                if (result != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            try (OutputStreamWriter writer = new OutputStreamWriter(
                    new FileOutputStream(file), StandardCharsets.UTF_8)) {
                // 写入BOM标记，以确保Windows记事本正确识别UTF-8编码
                writer.write('\ufeff');
                
                writer.write("LL(1)语法分析器 - 分析结果\n");
                writer.write("时间：" + sdf.format(new Date()) + "\n");
                writer.write("输入符号串：" + inputField.getText().trim() + "\n");
                writer.write("\n");
                writer.write(resultArea.getText());
                
                JOptionPane.showMessageDialog(this,
                    "结果已成功保存到：\n" + file.getAbsolutePath(),
                    "保存成功",
                    JOptionPane.INFORMATION_MESSAGE);
                
                createLogFile("结果已导出到：" + file.getAbsolutePath());
            } catch (Exception e) {
                logError("保存文件失败", e);
                showErrorDialog("保存文件失败：" + e.getMessage());
            }
        }
    }
} 