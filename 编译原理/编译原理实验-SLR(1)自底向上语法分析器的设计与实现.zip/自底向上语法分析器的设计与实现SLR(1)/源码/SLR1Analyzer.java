import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.List;

public class SLR1Analyzer extends JFrame {
    private JTextArea grammarArea;
    private JTextArea inputArea;
    private JTable analysisTable;
    private DefaultTableModel tableModel;
    private JTextArea resultArea;
    private SLR1Parser parser;
    
    public SLR1Analyzer() {
        setTitle("SLR(1) 分析程序 - 23智72 黄暄 239007045");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        parser = new SLR1Parser();
        
        // 创建文法显示区域
        grammarArea = new JTextArea();
        grammarArea.setEditable(false);
        grammarArea.setFont(new Font("宋体", Font.PLAIN, 14));
        grammarArea.setText("-------------SLR(1) 分析程序-------------\n" +
                          "制作人：23智72 黄暄 239007045\n" +
                          "待分析的文法如下:\n" +
                          "(1)E -> E + T\n" +
                          "(2)E -> E - T\n" +
                          "(3)E -> T\n" +
                          "(4)T -> T*F\n" +
                          "(5)T -> T/F\n" +
                          "(6)T -> F\n" +
                          "(7)F -> (E)\n" +
                          "(8)F -> i\n" +
                          "----------------------------------------\n");
        
        // 创建输入区域
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputArea = new JTextArea(3, 40);
        inputArea.setFont(new Font("宋体", Font.PLAIN, 14));
        JLabel inputLabel = new JLabel("请输入待分析的字符串(以#结尾):");
        inputLabel.setFont(new Font("宋体", Font.PLAIN, 14));
        inputPanel.add(inputLabel, BorderLayout.NORTH);
        inputPanel.add(new JScrollPane(inputArea), BorderLayout.CENTER);
        
        // 创建分析表
        String[] columnNames = {"步骤", "状态栈", "符号栈", "剩余输入串", "动作"};
        tableModel = new DefaultTableModel(columnNames, 0);
        analysisTable = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                if (getModel().getRowCount() > 0) {
                    Object value = getModel().getValueAt(row, 4); // 动作列
                    if (value != null && value.toString().startsWith("错误")) {
                        c.setBackground(new Color(255, 200, 200));
                    } else {
                        c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 240, 255));
                    }
                }
                return c;
            }
        };
        analysisTable.setFont(new Font("宋体", Font.PLAIN, 14));
        analysisTable.getTableHeader().setFont(new Font("宋体", Font.BOLD, 14));
        JScrollPane tableScrollPane = new JScrollPane(analysisTable);
        
        // 设置表格列宽
        analysisTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        analysisTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        analysisTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        analysisTable.getColumnModel().getColumn(3).setPreferredWidth(200);
        analysisTable.getColumnModel().getColumn(4).setPreferredWidth(200);
        
        // 设置表格行高
        analysisTable.setRowHeight(25);
        
        // 创建结果区域
        resultArea = new JTextArea(5, 40);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("宋体", Font.PLAIN, 14));
        
        // 创建按钮
        JButton analyzeButton = new JButton("开始分析");
        analyzeButton.setFont(new Font("宋体", Font.PLAIN, 14));
        analyzeButton.setPreferredSize(new Dimension(100, 30));
        analyzeButton.addActionListener(e -> analyze());
        
        // 布局
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.add(new JScrollPane(grammarArea), BorderLayout.NORTH);
        topPanel.add(inputPanel, BorderLayout.CENTER);
        topPanel.add(analyzeButton, BorderLayout.SOUTH);
        
        // 为结果区域添加边框和标题
        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        
        add(topPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
        
        // 设置窗口大小和位置
        setSize(1000, 800);
        setLocationRelativeTo(null);
        
        // 设置最小窗口大小
        setMinimumSize(new Dimension(800, 600));
    }
    
    private void analyze() {
        // 清空之前的分析结果
        tableModel.setRowCount(0);
        resultArea.setText("");
        
        String input = inputArea.getText().trim();
        if (!input.endsWith("#")) {
            resultArea.setText("错误：输入串必须以#结尾！");
            return;
        }
        
        List<SLR1Parser.AnalysisStep> steps = parser.analyze(input);
        
        // 显示分析步骤
        boolean hasError = false;
        String errorMessage = "";
        
        for (SLR1Parser.AnalysisStep step : steps) {
            tableModel.addRow(new Object[]{
                step.step,
                step.stateStack,
                step.symbolStack,
                step.input,
                step.action
            });
            if (step.isError) {
                hasError = true;
                errorMessage = step.action;
            }
        }
        
        if (hasError) {
            resultArea.setText("分析失败：" + errorMessage + "\n" +
                            "详细分析过程请查看上方表格。");
        } else {
            resultArea.setText("分析成功！该输入串是文法的句子。\n" +
                            "详细分析过程请查看上方表格。");
        }
    }
    
    public static void main(String[] args) {
        // 设置外观
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            new SLR1Analyzer().setVisible(true);
        });
    }
} 