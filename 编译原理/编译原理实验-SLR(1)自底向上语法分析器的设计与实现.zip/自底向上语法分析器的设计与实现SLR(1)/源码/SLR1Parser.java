import java.util.*;

public class SLR1Parser {
    // ACTION表
    private static final Map<Integer, Map<String, String>> ACTION = new HashMap<>();
    // GOTO表
    private static final Map<Integer, Map<String, Integer>> GOTO = new HashMap<>();
    
    static {
        // 初始化ACTION表
        for (int i = 0; i < 24; i++) {
            ACTION.put(i, new HashMap<>());
        }
        
        // 初始化GOTO表
        for (int i = 0; i < 24; i++) {
            GOTO.put(i, new HashMap<>());
        }
        
        // 填充ACTION表
        // 状态0
        ACTION.get(0).put("i", "s5");
        ACTION.get(0).put("(", "s4");
        
        // 状态1
        ACTION.get(1).put("+", "s6");
        ACTION.get(1).put("-", "s7");
        ACTION.get(1).put("#", "acc");
        
        // 状态2
        ACTION.get(2).put("+", "r3");
        ACTION.get(2).put("-", "r3");
        ACTION.get(2).put("*", "s8");
        ACTION.get(2).put("/", "s9");
        ACTION.get(2).put(")", "r3");
        ACTION.get(2).put("#", "r3");
        
        // 状态3
        ACTION.get(3).put("+", "r6");
        ACTION.get(3).put("-", "r6");
        ACTION.get(3).put("*", "r6");
        ACTION.get(3).put("/", "r6");
        ACTION.get(3).put(")", "r6");
        ACTION.get(3).put("#", "r6");
        
        // 状态4
        ACTION.get(4).put("i", "s5");
        ACTION.get(4).put("(", "s4");
        
        // 状态5
        ACTION.get(5).put("+", "r8");
        ACTION.get(5).put("-", "r8");
        ACTION.get(5).put("*", "r8");
        ACTION.get(5).put("/", "r8");
        ACTION.get(5).put(")", "r8");
        ACTION.get(5).put("#", "r8");
        
        // 状态6
        ACTION.get(6).put("i", "s5");
        ACTION.get(6).put("(", "s4");
        
        // 状态7
        ACTION.get(7).put("i", "s5");
        ACTION.get(7).put("(", "s4");
        
        // 状态8
        ACTION.get(8).put("i", "s5");
        ACTION.get(8).put("(", "s4");
        
        // 状态9
        ACTION.get(9).put("i", "s5");
        ACTION.get(9).put("(", "s4");
        
        // 状态10
        ACTION.get(10).put("+", "r1");
        ACTION.get(10).put("-", "r1");
        ACTION.get(10).put("*", "s8");
        ACTION.get(10).put("/", "s9");
        ACTION.get(10).put(")", "r1");
        ACTION.get(10).put("#", "r1");
        
        // 状态11
        ACTION.get(11).put("+", "r2");
        ACTION.get(11).put("-", "r2");
        ACTION.get(11).put("*", "s8");
        ACTION.get(11).put("/", "s9");
        ACTION.get(11).put(")", "r2");
        ACTION.get(11).put("#", "r2");
        
        // 状态12
        ACTION.get(12).put("+", "r4");
        ACTION.get(12).put("-", "r4");
        ACTION.get(12).put("*", "r4");
        ACTION.get(12).put("/", "r4");
        ACTION.get(12).put(")", "r4");
        ACTION.get(12).put("#", "r4");
        
        // 状态13
        ACTION.get(13).put("+", "r5");
        ACTION.get(13).put("-", "r5");
        ACTION.get(13).put("*", "r5");
        ACTION.get(13).put("/", "r5");
        ACTION.get(13).put(")", "r5");
        ACTION.get(13).put("#", "r5");
        
        // 状态14
        ACTION.get(14).put("+", "s6");
        ACTION.get(14).put("-", "s7");
        ACTION.get(14).put(")", "s15");
        
        // 状态15
        ACTION.get(15).put("+", "r7");
        ACTION.get(15).put("-", "r7");
        ACTION.get(15).put("*", "r7");
        ACTION.get(15).put("/", "r7");
        ACTION.get(15).put(")", "r7");
        ACTION.get(15).put("#", "r7");
        
        // 填充GOTO表
        // 状态0
        GOTO.get(0).put("E", 1);
        GOTO.get(0).put("T", 2);
        GOTO.get(0).put("F", 3);
        
        // 状态4
        GOTO.get(4).put("E", 14);
        GOTO.get(4).put("T", 2);
        GOTO.get(4).put("F", 3);
        
        // 状态6
        GOTO.get(6).put("T", 10);
        GOTO.get(6).put("F", 3);
        
        // 状态7
        GOTO.get(7).put("T", 11);
        GOTO.get(7).put("F", 3);
        
        // 状态8
        GOTO.get(8).put("F", 12);
        
        // 状态9
        GOTO.get(9).put("F", 13);
    }
    
    private List<String> productions;
    
    public SLR1Parser() {
        productions = new ArrayList<>();
        // 初始化产生式
        productions.add("E->E+T");
        productions.add("E->E-T");
        productions.add("E->T");
        productions.add("T->T*F");
        productions.add("T->T/F");
        productions.add("T->F");
        productions.add("F->(E)");
        productions.add("F->i");
    }
    
    public static class AnalysisStep {
        public int step;
        public String stateStack;
        public String symbolStack;
        public String input;
        public String action;
        public boolean isError;
        
        public AnalysisStep(int step, String stateStack, String symbolStack, String input, String action) {
            this.step = step;
            this.stateStack = stateStack;
            this.symbolStack = symbolStack;
            this.input = input;
            this.action = action;
            this.isError = false;
        }
        
        public AnalysisStep(int step, String stateStack, String symbolStack, String input, String action, boolean isError) {
            this(step, stateStack, symbolStack, input, action);
            this.isError = isError;
        }
    }
    
    public List<AnalysisStep> analyze(String input) {
        List<AnalysisStep> steps = new ArrayList<>();
        Stack<Integer> stateStack = new Stack<>();
        Stack<String> symbolStack = new Stack<>();
        
        // 初始化栈
        stateStack.push(0);
        symbolStack.push("#");
        
        int step = 1;
        int index = 0;
        
        try {
            while (true) {
                int currentState = stateStack.peek();
                String currentInput = index < input.length() ? String.valueOf(input.charAt(index)) : "#";
                
                // 记录当前步骤
                AnalysisStep currentStep = new AnalysisStep(
                    step++,
                    stateStack.toString(),
                    symbolStack.toString(),
                    input.substring(index),
                    ""  // 动作将在后面填充
                );
                steps.add(currentStep);
                
                // 获取动作
                String action = ACTION.get(currentState).get(currentInput);
                if (action == null) {
                    currentStep.action = "错误：在状态 " + currentState + " 输入 " + currentInput + " 时没有对应的动作";
                    currentStep.isError = true;
                    return steps;
                }
                
                // 执行动作
                if (action.equals("acc")) {
                    currentStep.action = "接受";
                    break;
                } else if (action.startsWith("s")) {  // 移进
                    int nextState = Integer.parseInt(action.substring(1));
                    stateStack.push(nextState);
                    symbolStack.push(currentInput);
                    index++;
                    currentStep.action = "移进：状态" + nextState;
                } else if (action.startsWith("r")) {  // 规约
                    int productionIndex = Integer.parseInt(action.substring(1)) - 1;
                    String production = productions.get(productionIndex);
                    String[] parts = production.split("->");
                    String left = parts[0];
                    String right = parts[1];
                    
                    // 弹出右部长度个符号和状态
                    for (int i = 0; i < right.length(); i++) {
                        stateStack.pop();
                        symbolStack.pop();
                    }
                    
                    // 压入左部非终结符
                    symbolStack.push(left);
                    
                    // 查找GOTO表得到下一个状态
                    Integer nextState = GOTO.get(stateStack.peek()).get(left);
                    if (nextState == null) {
                        currentStep.action = "错误：在状态 " + stateStack.peek() + " 无法找到非终结符 " + left + " 的GOTO项";
                        currentStep.isError = true;
                        return steps;
                    }
                    stateStack.push(nextState);
                    currentStep.action = "规约：使用" + production + "，转到状态" + nextState;
                }
            }
        } catch (Exception e) {
            // 如果发生任何其他错误，也返回已经记录的步骤
            if (!steps.isEmpty()) {
                AnalysisStep lastStep = steps.get(steps.size() - 1);
                lastStep.action = "错误：" + e.getMessage();
                lastStep.isError = true;
            }
        }
        
        return steps;
    }
} 